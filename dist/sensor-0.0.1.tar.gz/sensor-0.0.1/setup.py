from setuptools import find_packages, setup

setup(
    name='sensor',
    version='0.0.1',
    author='tanisha',
    author_email='tanisharao0704@gmail.com',
    packages=find_packages(),
)
